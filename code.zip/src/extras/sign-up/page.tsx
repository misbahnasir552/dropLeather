// 'use client';

// import { Form, Formik } from 'formik';
// import { useRouter } from 'next/navigation';
// import React from 'react';

// import CartIcon from '@/assets/icons/cartIcon.svg';
// import GlobalIcon from '@/assets/icons/global.svg';
// import QrIcon from '@/assets/icons/scanning.svg';
// import Button from '@/components/UI/Button/PrimaryButton';
// import H6 from '@/components/UI/Headings/H6';
// import CheckboxInput from '@/components/UI/Inputs/CheckboxInput';
// // import BreadCrumbLayout from '@/components/UI/Wrappers/BreadCrumbLayout';
// import FormWrapper from '@/components/UI/Wrappers/FormLayout';
// import HeaderWrapper from '@/components/UI/Wrappers/HeaderWrapper';
// import type { BusinessNatureForm, ICheckboxData } from '@/interfaces/interface';
// import {
//   businessNatureInitialValues,
//   businessNatureSchema,
// } from '@/validations/merchant/onBoarding/businessNatureSchema';

// const checkboxData: ICheckboxData[] = [
//   {
//     value: 'onlinePayments',
//     label: 'Online Payments',
//     logo: GlobalIcon,
//   },
//   {
//     value: 'qrPayments',
//     label: 'QR Payments',
//     logo: QrIcon,
//   },
//   {
//     value: 'miniApps',
//     label: 'Mini Apps',
//     logo: CartIcon,
//   },
// ];

// const AccountOptions = () => {
//   const router = useRouter();
//   const handleSubmit = (values: BusinessNatureForm, { setSubmitting }: any) => {
//     console.log(values);
//     router.push(
//       `/sign-up/personal-information/?option=${values.businessNature}`,
//     );
//     setSubmitting(false);
//   };
//   return (
//     <div className="flex flex-col gap-6 py-[76px]">
//       {/* <div className=""> */}
//       <HeaderWrapper
//         heading="What would you like to Sign up for?"
//         description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
//           eiusmodtempor incididunt ut labore et dolore"
//       />
//       {/* </div> */}
//       <Formik
//         initialValues={businessNatureInitialValues}
//         validationSchema={businessNatureSchema}
//         onSubmit={handleSubmit}
//       >
//         {(formik) => (
//           <Form>
//             <FormWrapper>
//               <div className="flex w-full flex-col items-start justify-between gap-4">
//                 <H6>Please Select One Option</H6>
//                 <CheckboxInput
//                   name="businessNature"
//                   options={checkboxData}
//                   form={formik}
//                 />
//               </div>
//               <div className="flex justify-center pt-8">
//                 <Button
//                   label="Next"
//                   type="submit"
//                   className="button-primary w-[270px] px-3 py-[19px] text-sm"
//                 />
//               </div>
//             </FormWrapper>
//           </Form>
//         )}
//       </Formik>
//     </div>
//   );
// };

// export default AccountOptions;
