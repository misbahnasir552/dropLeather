type User = {
  id: number;
  name: string;
  email: string;
};

type TEndpoint = string;
