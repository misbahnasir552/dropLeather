'use client';

import React, { useEffect, useState } from 'react';
import { BarLoader } from 'react-spinners';
import * as XLSX from 'xlsx';

import apiClient from '@/api/apiClient';
import Pagination from '@/components/Pagination/Pagination';
import IconTable from '@/components/Table/WithoutCheckMarksTable/WithImageTable/IconTable';
import Button from '@/components/UI/Button/PrimaryButton';
import ErrorModal from '@/components/UI/Modal/ErrorModal';
import QRModal from '@/components/UI/Modal/QR/QRModal';
import HeaderWrapper from '@/components/UI/Wrappers/HeaderWrapper';
import { useAppSelector } from '@/hooks/redux';

function StaticQr() {
  const userData = useAppSelector((state: any) => state.auth);
  const [imageUrl, setImageUrl] = useState('');
  const [storeName, setStoreName] = useState('');

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [stores, setStores] = useState([]);
  const [tillNum, setTillNum] = useState<string>('');
  const [isLoading, setIsloading] = useState(false);
  const [pageNumber, setPageNumber] = useState(0);
  const envPageSize = process.env.NEXT_PUBLIC_PAGE_SIZE || 10;
  const [totalPages, setTotalPages] = useState<number>(+envPageSize);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [qrString, setQrString] = useState('');

  const base64ToJpg = (base64String: any) => {
    console.log('base 64 is', base64String);
    if (!base64String) {
      console.error('Base64 string is undefined or null.');
      return;
    }

    let byteString;

    // Check if the Base64 string contains the header
    if (base64String.includes('base64,')) {
      // Ensure the Base64 string is correctly formatted and split
      try {
        [, byteString] = base64String.split(','); // Use array destructuring
      } catch (error) {
        console.error('Error decoding Base64 string:', error);
        return;
      }
    } else {
      try {
        const cleanBase64String = base64String.replace(/[^A-Za-z0-9+/=]/g, '');
        byteString = atob(cleanBase64String);
        // byteString = atob(base64String); // Assume it’s already clean Base64
      } catch (error) {
        console.error('Error decoding Base64 string:', error);
        return;
      }
    }

    // Extract MIME type from the string if available
    let mimeString = 'image/jpeg'; // Default to JPEG
    if (base64String.includes('data:')) {
      [mimeString] = base64String.split(',')[0].split(':')[1].split(';'); // Use array destructuring
    }

    // Convert the Base64 string to an ArrayBuffer and create a Blob
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);

    for (let i = 0; i < byteString.length; i += 1) {
      // Replace ++ with i += 1
      uint8Array[i] = byteString.charCodeAt(i);
    }

    const blob = new Blob([uint8Array], { type: mimeString });
    const imageUrl = URL.createObjectURL(blob);

    setImageUrl(imageUrl); // Update the state to display the image
    setShowModal(true);
  };
  const handleView = (qrCode: string, name: string, tillId?: string) => {
    setTillNum(tillId || '');
    base64ToJpg(qrCode);
    setQrString(qrCode);
    setStoreName(name);
  };

  const fetchStores = async () => {
    setIsloading(true);
    try {
      const response = await apiClient.get('/merchant/stores', {
        headers: { Authorization: `Bearer ${userData?.jwt}` },
        params: {
          merchantEmail: userData?.email,
          page: pageNumber,
          size: +envPageSize,
        },
      });
      // setTitle('merchantPortalProfile');

      if (response.data.responseCode === '009') {
        const filterValues = response?.data?.merchantStores.map(
          (item: any) => item,
        );
        setStores(
          filterValues?.map((item: any) => {
            return {
              ...item,
              tillNumber: item?.transactionPointNumber,
            };
          }),
        );
        setTotalPages(response?.data?.totalPages);
      } else if (response.data.responseCode === '000') {
        setTitle(response?.data?.responseMessage);
        setDescription(response.data.responseDescription);
        setShowErrorModal(true);
      } else {
        setTitle(response?.data?.responseMessage);
        setDescription(response.data.responseDescription);
        setShowErrorModal(true);
      }
    } catch (error: any) {
      console.error('Error fetching merchant stores:', error);
      setDescription(error?.message);
      setShowErrorModal(true);
    } finally {
      setIsloading(false);
    }
  };

  useEffect(() => {
    if (userData?.email) {
      fetchStores();
    }
  }, [userData?.email, pageNumber]);
  const qrPaymentsTableHeadings: string[] = [
    'Store ID',
    'Store Name',
    // 'Website URL',
    // 'Payment Enabled',
    // 'Branch',
    'Transaction Point Number',
    'Store Address',
    'QR Generation Date/Time',
    // 'QR Expiry Date',
    'SMS Notification Number',
    'Actions',
  ];
  // const onSubmit = (values: IQrPayments) => {
  //   console.log('StaticQr', values);
  // };
  // const handleReset = (Formik: any) => {
  //   Formik.resetForm();
  // };
  const exportToExcel = () => {
    // if (!stores) return;

    if (!stores) {
      return;
    }

    // Create a worksheet from the stores data
    const ws = XLSX?.utils?.json_to_sheet(stores);

    // Create a new workbook and append the worksheet
    const wb = XLSX?.utils?.book_new();
    XLSX?.utils?.book_append_sheet(wb, ws, 'Static QR Report');

    // Generate an Excel file and download it
    XLSX.writeFile(wb, 'Static-QR-Report.xlsx');
  };
  const showNextPage = () => {
    setPageNumber((prev) => Math.min(prev + 1, totalPages - 1));
    // fetchRecords()
  };

  const showPrevPage = () => {
    setPageNumber((prev) => Math.max(prev - 1, 0));
  };
  return (
    <div>
      <>
        {isLoading && <BarLoader color="#21B25F" />}
        {showErrorModal && (
          <ErrorModal
            title={title}
            description={description}
            show={showErrorModal}
            setShow={setShowErrorModal}
            // routeName="/merchant/merchant-portal/qr-payments/dynamic-qr/"
          />
        )}
        {imageUrl && showModal && (
          <QRModal
            title={storeName}
            description="Your static QR Code has been created. You can now share the below QR code to receive money."
            show={showModal}
            setShowModal={setShowModal}
            imageUrl={imageUrl} // Pass the QR code image URL here
            tilNum={tillNum}
            qrString={qrString}
            isStatic={true}
            // amount={amount}
            // expirationTime={expirationTime}
          />
        )}
        <div className="flex flex-col gap-6">
          <HeaderWrapper
            heading="View QR"
            // description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmodtempor incididunt ut labore et dolore"
          />
          {/* <MerchantFormLayout>
            <Formik
              initialValues={qrPaymentsInitialValues}
              validationSchema={qrPaymentsSchema}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="bg-screen-grey">
                  <div className="mb-9 grid gap-5 bg-screen-grey sm:grid-cols-1 md:grid-cols-3 ">
                    <Input
                      label="Store Name"
                      name="storeName"
                      type="text"
                      // error={"hi"}
                      formik={formik}
                    // touched={formik.touched.CardNumber}
                    />
                    <Input
                      label="Transaction Point Number"
                      name="transactionPointNumber"
                      formik={formik}
                      type="text"
                      error={'hi'}
                      touched={false}
                    />
                    <Input
                      label="Store ID"
                      name="storeId"
                      type="text"
                      // error={"hi"}
                      formik={formik}
                    // touched={formik.touched.CardNumber}
                    />
                    <DropdownInput
                      label="Status"
                      options={[
                        { label: 'Active', value: 'Active' },
                        { label: 'In-Active', value: 'InActive' },
                      ]}
                      name="status"
                      formik={formik}
                    />
                  </div>
                  <div className="flex w-full justify-start gap-6">
                    <Button
                      label="Search"
                      type="submit"
                      className="button-primary h-9 w-[120px] px-3 py-[19px] text-sm"
                    />
                    <Button
                      label="Reset"
                      // routeName="/login"
                      onClickHandler={() => handleReset(formik)}
                      className="button-secondary h-9 w-[120px] px-2 py-[11px] text-xs leading-tight"
                    />
                  </div>
                </Form>
              )}
            </Formik>
          </MerchantFormLayout> */}
          {/* <div className="flex flex-col p-[60px] bg-screen-grey border-[0.5px] border-border-light rounded-lg"></div> */}
        </div>
        {stores?.length > 0 && (
          <div className="flex justify-end">
            <Button
              label="Export"
              className="button-secondary w-[120px] px-2 py-[11px] text-xs leading-tight transition duration-300"
              onClickHandler={exportToExcel} // Export button click handler
            />
          </div>
        )}
        <div className="flex flex-col justify-center gap-3 pt-[30px]">
          {stores?.length > 0 ? (
            <>
              {' '}
              <IconTable
                tableHeadings={qrPaymentsTableHeadings}
                tableData={stores}
                // hasEdit
                handleView={handleView}
                hasShare
              />
              <Pagination
                pageNumber={pageNumber}
                totalPages={totalPages}
                onNext={showNextPage}
                onPrev={showPrevPage}
              />
            </>
          ) : (
            <div className="text-center">No Data Available</div>
          )}
        </div>
      </>
    </div>
  );
}

export default StaticQr;
