import MerchantProfile from '@/components/Profile/MerchantProfile';

const page = () => {
  return <MerchantProfile />;
};

export default page;
