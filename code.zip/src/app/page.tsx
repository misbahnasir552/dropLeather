'use client';

import Home from '@/components/Content/Home/Home';

export default function HomePage() {
  return (
    <main>
      <Home />
    </main>
  );
}
