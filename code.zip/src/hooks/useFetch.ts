// import { useQuery } from '@tanstack/react-query';

// import { getAllUsers } from '@/api/user';

// const useFetchMovieById = () => useQuery(['user', userId], () => getAllUsers());

// export default useFetchMovieById;
