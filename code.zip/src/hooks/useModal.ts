// import { useState } from 'react';
// import { ICustomModalHookProps } from '@/interfaces/interface';
// const useModal = () => {
//   const [showModal, setShowModal] = useState(false);
//   const [title, setTitle] = useState('');
//   const [description, setDescription] = useState('');

//   const openModal = ({ modalTitle, modalDescription }: ICustomModalHookProps) => {
//     setTitle(modalTitle);
//     setDescription(modalDescription);
//     setShowModal(true);
//   };

//   const closeModal = () => {
//     setShowModal(false);
//     setTitle('');
//     setDescription('');
//   };

//   return {
//     showModal,
//     title,
//     description,
//     openModal,
//     closeModal,
//   };
// };

// export default useModal;
