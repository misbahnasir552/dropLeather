// import React from 'react';
// import Modal from 'react-modal';

// import SignUpForm from '@/app/sign-up/page2';

// interface CustomModalProps {
//   isOpen: boolean;
//   onRequestClose: () => void;
//   contentLabel: string;
//   className: string;
// }

// const CustomModal: React.FC<CustomModalProps> = ({
//   isOpen,
//   onRequestClose,
//   contentLabel,
//   className,
// }) => {
//   return (
//     <Modal
//       ariaHideApp={false}
//       isOpen={isOpen}
//       onRequestClose={onRequestClose}
//       contentLabel={contentLabel}
//       className={className}
//       shouldCloseOnOverlayClick={true}
//       overlayClassName={''}
//     >
//       <SignUpForm onSubmit={() => console.log('submitteddddd')} />
//     </Modal>
//   );
// };

// export default CustomModal;
