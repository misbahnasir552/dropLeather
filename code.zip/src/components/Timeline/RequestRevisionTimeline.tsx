'use client';

import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { BarLoader } from 'react-spinners';

import apiClient from '@/api/apiClient';
// import RequestRevision from '@/app/merchant/home/request-revision/[form]/page';
import { useAppSelector } from '@/hooks/redux';
import useCurrentTab from '@/hooks/useCurrentTab';
import { setIsLastTab } from '@/redux/features/formSlices/lastTabSlice';

import ActivityInformationReqRevision from '../Forms/ActivityInformationReqRevision';
import BusinessInformationReqRevision from '../Forms/BusinessDetailsReqRevision';
import IntegrationFormReqRevision from '../Forms/IntegrationFormReqRevision';
import SettlementDetailsReqRevision from '../Forms/SettlementDetailReqRevision';
import StoreDetailReqRevision from '../Forms/StoreDetailReqRevision';
import {
  ActivityInformationIcon,
  BusinessDetailsIcon,
  IntegrationsIcon,
  SettlementDetailsIcon,
} from './TimelineIcons/Timelineicons';

interface Tab {
  name: string;
  label: string;
  component: JSX.Element;
  status: string;
  svg: JSX.Element;
}

interface UserData {
  email: string;
}

interface MerchantData {
  page: { pageName: string }[];
}

const nameToLabelMapping: Record<string, string> = {
  'Activity Information': 'Activity Information',
  'Business Details': 'Business Details',
  'Store Details': 'Store Details',
  'Settlement Details': 'Settlement Details',
  Integration: 'Integration',
  Documents: 'Attachments',
  'Review Form': 'Review Form',
};

const allTabs: Tab[] = [
  {
    name: 'activity-information',
    label: 'Activity Information',
    component: <ActivityInformationReqRevision />,
    svg: <ActivityInformationIcon color="#6F6B76" />,
    status: '',
  },
  {
    name: 'business-details',
    label: 'Business Details',
    component: <BusinessInformationReqRevision />,
    svg: <BusinessDetailsIcon color="#6F6B76" />,
    status: '',
  },
  {
    name: 'store-details',
    label: 'Store Details',
    component: <StoreDetailReqRevision />,
    svg: <BusinessDetailsIcon color="#6F6B76" />,
    status: '',
  },
  {
    name: 'settlement-details',
    label: 'Settlement Details',
    component: <SettlementDetailsReqRevision />,
    svg: <SettlementDetailsIcon color="#6F6B76" />,
    status: '',
  },
  {
    name: 'integration',
    label: 'Integration',
    component: <IntegrationFormReqRevision />,
    svg: <IntegrationsIcon color="#6F6B76" />,
    status: '',
  },
];

const getFilteredTabs = (fetchedPages: { pageName: string }[], tabs: Tab[]) => {
  return fetchedPages
    .map((page) => {
      const matchedTab = tabs.find(
        (tab) => tab.label === nameToLabelMapping[page.pageName],
      );
      return matchedTab ? { ...matchedTab, status: 'Completed' } : undefined;
    })
    .filter((tab): tab is Tab => tab !== undefined)
    .sort((a, b) =>
      a.label === 'Activity Information'
        ? -1
        : b.label === 'Activity Information'
        ? 1
        : 0,
    );
};

const RequestRevisionTimeline: React.FC = () => {
  const userData = useAppSelector((state: { auth: UserData }) => state.auth);
  const { currentTab } = useCurrentTab();
  const activeTab = currentTab;
  const [data, setData] = useState<MerchantData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const dispatch = useDispatch();

  useEffect(() => {
    const getDetails = async () => {
      try {
        console.log('Fetching details...');
        const response = await apiClient.get(
          `merchant/fieldsForRevision?email=${userData?.email}`,
        );
        console.log('Response received:', response?.data);

        if (response?.data) {
          setData(response?.data);
          console.log('Data set successfully.');
        } else {
          console.error('Empty response data.');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    getDetails();
  }, []);

  if (isLoading) {
    return (
      <div className="flex w-full items-center justify-center">
        <BarLoader color="#21B25F" />
      </div>
    );
  }

  if (!data || !data.page) {
    return <div>No data available.</div>;
  }

  const filteredTabs = getFilteredTabs(data.page, allTabs);

  const currentTabIndex = filteredTabs.findIndex(
    (tab) => tab.name === activeTab,
  );
  const isLastTab = currentTabIndex === filteredTabs.length - 1;
  console.log(' isLastTab', isLastTab);

  if (isLastTab) {
    dispatch(setIsLastTab(true)); // Dispatch the action to set isLastTab to true
  }

  if (!isLastTab) {
    dispatch(setIsLastTab(false)); // Dispatch the action to set isLastTab to true
  }

  // Update the component prop with the correct isLastTab value
  const finalTabs = filteredTabs.map((tab) => ({
    ...tab,
    component: React.cloneElement(tab.component, { isLastTab }),
  }));

  console.log('islast tab in timeline', isLastTab);
  console.log('filtered tabs', filteredTabs);
  console.log('updated tabs', finalTabs);

  return (
    <div className="flex flex-col justify-between py-2">
      <div className="flex w-full justify-between overflow-auto">
        {finalTabs.map((tab, index) => (
          <React.Fragment key={index}>
            <div className="flex flex-col">
              <Link
                href={
                  tab.status === 'Completed'
                    ? `/merchant/home/request-revision/${tab.name}`
                    : '#'
                }
                className={`${
                  tab.status === 'Completed'
                    ? 'cursor-pointer'
                    : 'cursor-not-allowed opacity-50'
                }`}
              >
                <div className="flex justify-center px-[14px] pb-[8px]">
                  <div
                    className={`flex w-max rounded-lg border-[1px] ${
                      tab.name === activeTab
                        ? 'border-border-green'
                        : tab.status === 'Completed'
                        ? 'border-secondary-base bg-screen-grey'
                        : 'border-border-light'
                    } p-[12px]`}
                  >
                    {tab.svg}
                  </div>
                </div>
                <div className="flex w-full justify-center text-center text-xs font-semibold leading-[14px] text-secondary-base">
                  {tab.label}
                </div>
              </Link>
            </div>
          </React.Fragment>
        ))}
      </div>
      {/* <RequestRevision isLastTab={isLastTab} /> */}
    </div>
  );
};

export default RequestRevisionTimeline;
