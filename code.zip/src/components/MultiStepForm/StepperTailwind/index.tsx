// 'use client';

// import type { Dispatch, SetStateAction } from 'react';
// import React, { useState } from 'react';
// import { Stepper } from 'react-form-stepper';

// interface IStepperFormTailwind {
//   setActiveStep: Dispatch<SetStateAction<number>>;
//   activeStep: number;
// }

// const StepperFormTailwind = ({
//   setActiveStep,
//   activeStep,
// }: IStepperFormTailwind) => {
//   // const [activeStep, setActiveStep] = useState();
//   return (
//     <div className="px-[150px]">
//       <Stepper
//         steps={[
//           { label: 'Activity Information' },
//           { label: 'Business Information' },
//           { label: 'Additional Information' },
//         ]}
//         activeStep={activeStep}
//       />
//     </div>
//   );
// };

// export default StepperFormTailwind;
