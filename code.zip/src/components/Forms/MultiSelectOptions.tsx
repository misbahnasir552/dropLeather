// 'use client';

// // import CheckboxInput from '@/components/UI/Inputs/CheckboxInput3';
// import type { ICheckboxInput } from '@/interfaces/interface';

// interface Props {
//   selectedItems: any[]; // Adjust type if necessary
//   setSelectedItems: React.Dispatch<React.SetStateAction<any[]>>; // Adjust type if necessary
//   checkboxData: ICheckboxInput[];
// }

// function MultiSelectOptions({
//   selectedItems,
//   setSelectedItems,
//    // checkboxData,
// }: Props) {
//   // console.log('Selected items', selectedItems, setSelectedItems);

//   return (
//     <div className="flex w-full flex-col items-start justify-between gap-4">
//       {/* {checkboxData.map((checkBox, index) => (
//         <CheckboxInput {...checkBox} key={index} />
//       ))} */}
//     </div>
//   );
// }

// export default MultiSelectOptions;
