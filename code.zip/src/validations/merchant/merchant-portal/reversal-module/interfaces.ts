export interface IReversalBulkBatch {
  batchId: string;
  reversalDateBetween: string;
  status: string;
}
